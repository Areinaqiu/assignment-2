python3 test_model_general.py --name map_translation --num_test 30000 --dataset_mode map --gpu_ids 0
